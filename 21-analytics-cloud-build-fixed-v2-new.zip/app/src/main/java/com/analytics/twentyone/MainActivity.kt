package com.analytics.twentyone

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.graphics.Color
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val requestCapture = 7001
    private lateinit var status: TextView
    private lateinit var statsView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "21 Analytics Scanner"
            textSize = 25f
            setTextColor(Color.BLACK)
        }
        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, 22, 0, 18)
        }
        val start = Button(this).apply {
            text = "Начать считывание экрана"
            setOnClickListener { requestScreenCapture() }
        }
        val stop = Button(this).apply {
            text = "Остановить"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "Захват остановлен."
                refreshStats()
            }
        }
        statsView = TextView(this).apply {
            textSize = 20f
            setTextColor(Color.BLACK)
            setPadding(12, 28, 12, 28)
            text = "X — 0\nR — 0"
        }
        val refresh = Button(this).apply {
            text = "Обновить статистику"
            setOnClickListener { refreshStats() }
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(start)
        layout.addView(stop)
        layout.addView(refresh)
        layout.addView(statsView)
        setContentView(layout)
        refreshStatus()
        refreshStats()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshStatus()
        if (::statsView.isInitialized) refreshStats()
    }

    private fun refreshStatus() {
        val prefs = getSharedPreferences(CaptureService.PREFS, MODE_PRIVATE)
        status.text = if (prefs.getBoolean(CaptureService.KEY_ACTIVE, false)) {
            "Захват включён. Вернись в 1xBet — анализ идёт автоматически."
        } else {
            "Готов к запуску. Открой игру 1xBet, затем начни захват экрана."
        }
    }

    private fun refreshStats() {
        val stats = RoundStore(this).stats()
        statsView.text = "X  •  НИЧЬИ: ${stats.draws}\n\n" +
            "R  •  СРАЗУ НА 2 КАРТАХ: ${stats.finishedOnDeal}\n\n" +
            "Завершённых раундов: ${stats.finished}\n" +
            "R пока не распознано: ${stats.unknownR}"
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }

    @Deprecated("Deprecated by Android API; kept for broad device compatibility in this prototype")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture) {
            if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, CaptureService::class.java).apply {
                    putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(CaptureService.EXTRA_RESULT_DATA, data)
                }
                startForegroundService(service)
                getSharedPreferences(CaptureService.PREFS, MODE_PRIVATE).edit()
                    .putBoolean(CaptureService.KEY_ACTIVE, true).apply()
                status.text = "Захват включён. Переключись в 1xBet — анализ продолжается в фоне."
            } else {
                status.text = "Разрешение на захват экрана не предоставлено."
            }
        }
    }
}
