package com.analytics.twentyone

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "21analytics_capture"
        private const val NOTIFICATION_ID = 2101
        const val PREFS = "21analytics_capture"
        const val KEY_ACTIVE = "capture_active"
        const val KEY_LOG = "ocr_log"
    }

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var worker: HandlerThread? = null
    private var handler: Handler? = null
    private val processing = AtomicBoolean(false)
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private var lastText = ""
    private lateinit var roundStore: RoundStore

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        ServiceCompat.startForeground(
            this, NOTIFICATION_ID, notification("Ожидание экрана…"),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
        )

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (data == null || resultCode == 0) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            roundStore = RoundStore(this)
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            beginCapture()
        } catch (e: Exception) {
            updateNotification("Не удалось начать захват: ${e.message ?: "ошибка"}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun beginCapture() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        worker = HandlerThread("21analytics-ocr").also { it.start() }
        handler = Handler(worker!!.looper)
        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }
        projection?.registerCallback(projectionCallback!!, handler)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ imageReader ->
            val image = imageReader.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (!processing.compareAndSet(false, true)) {
                image.close()
                return@setOnImageAvailableListener
            }
            val bitmap = imageToBitmap(image)
            image.close()
            if (bitmap == null) {
                processing.set(false)
                return@setOnImageAvailableListener
            }
            // Read the whole screen for round/status/scores, and separately crop
            // the two card rows. These coordinates match the current 1xBet table
            // layout; unknown crop OCR is kept unknown rather than counted as zero.
            val fullTask = recognizer.process(InputImage.fromBitmap(bitmap, 0))
            val playerCrop = cropRelative(bitmap, 0.22f, 0.355f, 0.56f, 0.105f)
            val dealerCrop = cropRelative(bitmap, 0.22f, 0.485f, 0.56f, 0.105f)
            if (playerCrop == null || dealerCrop == null) {
                playerCrop?.recycle(); dealerCrop?.recycle(); bitmap.recycle()
                processing.set(false)
                return@setOnImageAvailableListener
            }
            val playerTask = recognizer.process(InputImage.fromBitmap(playerCrop, 0))
            val dealerTask = recognizer.process(InputImage.fromBitmap(dealerCrop, 0))
            Tasks.whenAllSuccess<Text>(fullTask, playerTask, dealerTask)
                .addOnSuccessListener { results ->
                    val fullText = results[0].text.trim()
                    val playerText = results[1].text.trim()
                    val dealerText = results[2].text.trim()
                    val fingerprint = "$fullText\nP:$playerText\nD:$dealerText"
                    if (fingerprint.isNotEmpty() && fingerprint != lastText) {
                        lastText = fingerprint
                        appendOcrLog(fullText)
                        val snapshot = ScreenTextParser.parse(fullText, playerText, dealerText)
                        if (snapshot.roundId != null) {
                            roundStore.save(snapshot)
                            val state = when (snapshot.status) {
                                ScreenStatus.FINISHED -> "Раунд ${snapshot.roundId}: завершён"
                                ScreenStatus.IN_PROGRESS -> "Раунд ${snapshot.roundId}: идёт игра"
                                ScreenStatus.UNKNOWN -> "Раунд ${snapshot.roundId}: состояние неясно"
                            }
                            updateNotification(state)
                        } else {
                            updateNotification("Экран считывается • номер раунда пока не найден")
                        }
                    }
                }
                .addOnFailureListener { updateNotification("Ошибка распознавания экрана/карт") }
                .addOnCompleteListener {
                    playerCrop.recycle()
                    dealerCrop.recycle()
                    bitmap.recycle()
                    processing.set(false)
                }
        }, handler)

        virtualDisplay = projection?.createVirtualDisplay(
            "21AnalyticsDisplay", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, handler
        )
        updateNotification("Захват экрана активен")
    }


    private fun cropRelative(source: Bitmap, x: Float, y: Float, w: Float, h: Float): Bitmap? {
        val left = (source.width * x).toInt().coerceIn(0, source.width - 1)
        val top = (source.height * y).toInt().coerceIn(0, source.height - 1)
        val width = (source.width * w).toInt().coerceAtMost(source.width - left)
        val height = (source.height * h).toInt().coerceAtMost(source.height - top)
        if (width < 2 || height < 2) return null
        return Bitmap.createBitmap(source, left, top, width, height)
    }

    private fun appendOcrLog(text: String) {
        val time = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
            .format(java.util.Date())
        val snapshot = ScreenTextParser.parse(text)
        val parsed = if (snapshot.roundId != null) {
            " • раунд ${snapshot.roundId} • ${snapshot.status}"
        } else {
            " • номер раунда не распознан"
        }
        val entry = "[$time]$parsed\n$text\n\n"
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val old = prefs.getString(KEY_LOG, "") ?: ""
        prefs.edit().putString(KEY_LOG, (old + entry).takeLast(14000))
            .putBoolean(KEY_ACTIVE, true).apply()
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val paddedWidth = image.width + rowPadding / pixelStride
            val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
            padded.copyPixelsFromBuffer(buffer)
            Bitmap.createBitmap(padded, 0, 0, image.width, image.height).also {
                padded.recycle()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "21 Analytics screen capture",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("21 Analytics Scanner")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, notification(message))
    }

    override fun onDestroy() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putBoolean(KEY_ACTIVE, false).apply()
        virtualDisplay?.release()
        reader?.close()
        projectionCallback?.let { projection?.unregisterCallback(it) }
        projection?.stop()
        worker?.quitSafely()
        recognizer.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
