package com.analytics.twentyone

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class LocalStats(
    val finished: Int,
    val draws: Int,
    val finishedOnDeal: Int,
    val unknownR: Int
)

class RoundStore(context: Context) : SQLiteOpenHelper(context, "21analytics.db", null, 3) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE rounds (
                round_id INTEGER PRIMARY KEY,
                status TEXT NOT NULL,
                player_score INTEGER,
                dealer_score INTEGER,
                turn TEXT,
                is_draw INTEGER,
                finished_on_deal INTEGER,
                player_card_count INTEGER,
                dealer_card_count INTEGER,
                raw_text TEXT NOT NULL,
                updated_at INTEGER NOT NULL
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE rounds ADD COLUMN is_draw INTEGER")
            db.execSQL("ALTER TABLE rounds ADD COLUMN finished_on_deal INTEGER")
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE rounds ADD COLUMN player_card_count INTEGER")
            db.execSQL("ALTER TABLE rounds ADD COLUMN dealer_card_count INTEGER")
        }
    }

    fun save(snapshot: ScreenSnapshot) {
        val id = snapshot.roundId ?: return
        var playerCards = snapshot.playerCardCount
        var dealerCards = snapshot.dealerCardCount
        var playerScore = snapshot.playerScore
        var dealerScore = snapshot.dealerScore
        var status = snapshot.status
        readableDatabase.rawQuery(
            "SELECT status, player_score, dealer_score, player_card_count, dealer_card_count FROM rounds WHERE round_id = ?",
            arrayOf(id.toString())
        ).use { c ->
            if (c.moveToFirst()) {
                if (status == ScreenStatus.UNKNOWN) status = runCatching { ScreenStatus.valueOf(c.getString(0)) }.getOrDefault(status)
                if (playerScore == null && !c.isNull(1)) playerScore = c.getInt(1)
                if (dealerScore == null && !c.isNull(2)) dealerScore = c.getInt(2)
                if (playerCards == null && !c.isNull(3)) playerCards = c.getInt(3)
                if (dealerCards == null && !c.isNull(4)) dealerCards = c.getInt(4)
            }
        }
        val finished = status == ScreenStatus.FINISHED
        val draw: Int? = if (finished && playerScore != null && dealerScore != null) {
            if (playerScore == dealerScore) 1 else 0
        } else null
        val r: Int? = if (finished && playerCards != null && dealerCards != null) {
            if (playerCards == 2 && dealerCards == 2) 1 else 0
        } else null
        val values = ContentValues().apply {
            put("round_id", id)
            put("status", status.name)
            if (playerScore == null) putNull("player_score") else put("player_score", playerScore)
            if (dealerScore == null) putNull("dealer_score") else put("dealer_score", dealerScore)
            put("turn", snapshot.turn)
            if (draw == null) putNull("is_draw") else put("is_draw", draw)
            if (r == null) putNull("finished_on_deal") else put("finished_on_deal", r)
            if (playerCards == null) putNull("player_card_count") else put("player_card_count", playerCards)
            if (dealerCards == null) putNull("dealer_card_count") else put("dealer_card_count", dealerCards)
            put("raw_text", snapshot.rawText)
            put("updated_at", System.currentTimeMillis())
        }
        writableDatabase.insertWithOnConflict(
            "rounds", null, values, SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun stats(): LocalStats {
        readableDatabase.rawQuery(
            "SELECT COUNT(*), COALESCE(SUM(CASE WHEN is_draw = 1 THEN 1 ELSE 0 END), 0), " +
                "COALESCE(SUM(CASE WHEN finished_on_deal = 1 THEN 1 ELSE 0 END), 0), " +
                "COALESCE(SUM(CASE WHEN finished_on_deal IS NULL THEN 1 ELSE 0 END), 0) " +
                "FROM rounds WHERE status = 'FINISHED'", null
        ).use { cursor ->
            return if (cursor.moveToFirst()) {
                LocalStats(cursor.getInt(0), cursor.getInt(1), cursor.getInt(2), cursor.getInt(3))
            } else LocalStats(0, 0, 0, 0)
        }
    }
}
