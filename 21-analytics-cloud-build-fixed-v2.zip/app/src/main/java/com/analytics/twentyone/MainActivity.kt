package com.analytics.twentyone

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.graphics.Color
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val requestCapture = 7001
    private lateinit var status: TextView
    private lateinit var logView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "21 Analytics Scanner"
            textSize = 25f
            setTextColor(Color.BLACK)
        }
        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, 22, 0, 18)
        }
        val start = Button(this).apply {
            text = "Начать считывание экрана"
            setOnClickListener { requestScreenCapture() }
        }
        val stop = Button(this).apply {
            text = "Остановить"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "Захват остановлен."
                refreshLog()
            }
        }
        val refresh = Button(this).apply {
            text = "Обновить журнал OCR"
            setOnClickListener { refreshLog() }
        }
        logView = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(12, 12, 12, 12)
            text = "Журнал пока пуст. Включи захват и открой игру 1xBet."
        }
        val scroll = ScrollView(this).apply {
            addView(logView)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(start)
        layout.addView(stop)
        layout.addView(refresh)
        layout.addView(scroll)
        setContentView(layout)
        refreshStatus()
        refreshLog()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshStatus()
        if (::logView.isInitialized) refreshLog()
    }

    private fun refreshStatus() {
        val prefs = getSharedPreferences(CaptureService.PREFS, MODE_PRIVATE)
        status.text = if (prefs.getBoolean(CaptureService.KEY_ACTIVE, false)) {
            "Захват включён. OCR записывается в журнал ниже."
        } else {
            "Готов к запуску. Открой игру 1xBet, затем начни захват экрана."
        }
    }

    private fun refreshLog() {
        val prefs = getSharedPreferences(CaptureService.PREFS, MODE_PRIVATE)
        val log = prefs.getString(CaptureService.KEY_LOG, "") ?: ""
        logView.text = if (log.isBlank()) {
            "Журнал пока пуст. Включи захват и открой игру 1xBet."
        } else {
            "ПОСЛЕДНИЕ РЕЗУЛЬТАТЫ OCR\n\n$log"
        }
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }

    @Deprecated("Deprecated by Android API; kept for broad device compatibility in this prototype")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture) {
            if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, CaptureService::class.java).apply {
                    putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(CaptureService.EXTRA_RESULT_DATA, data)
                }
                startForegroundService(service)
                getSharedPreferences(CaptureService.PREFS, MODE_PRIVATE).edit()
                    .putBoolean(CaptureService.KEY_ACTIVE, true).apply()
                status.text = "Захват включён. Открой 1xBet; OCR появится в журнале ниже."
            } else {
                status.text = "Разрешение на захват экрана не предоставлено."
            }
        }
    }
}
