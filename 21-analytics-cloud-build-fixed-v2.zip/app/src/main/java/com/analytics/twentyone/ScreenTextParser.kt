package com.analytics.twentyone

data class ScreenSnapshot(
    val roundId: Int?,
    val playerScore: Int?,
    val dealerScore: Int?,
    val status: ScreenStatus,
    val turn: String?,
    val rawText: String
)

enum class ScreenStatus { IN_PROGRESS, FINISHED, UNKNOWN }

object ScreenTextParser {
    private val roundPatterns = listOf(
        Regex("""(?:№|#)\s*(\d{1,8})""", RegexOption.IGNORE_CASE),
        Regex("""21\s*Очко[.\s]*(\d{1,8})""", RegexOption.IGNORE_CASE),
        Regex("""N\s*(\d{1,8})""", RegexOption.IGNORE_CASE)
    )
    private val scoreRegex = Regex("""(?<!\d)(\d{1,2})\s*:\s*(\d{1,2})(?!\d)""")
    private val playerTurnRegex = Regex("""ход\s+игрока""", RegexOption.IGNORE_CASE)
    private val dealerTurnRegex = Regex("""ход\s+дилера""", RegexOption.IGNORE_CASE)
    private val finishedRegex = Regex("""игра\s+завершена""", RegexOption.IGNORE_CASE)

    fun parse(text: String): ScreenSnapshot {
        val normalized = text.replace('\n', ' ').replace(Regex("""\s+"""), " ").trim()
        val round = roundPatterns.firstNotNullOfOrNull { regex ->
            regex.find(normalized)?.groupValues?.getOrNull(1)?.toIntOrNull()
        }
        val score = scoreRegex.find(normalized)
        val status = when {
            finishedRegex.containsMatchIn(normalized) -> ScreenStatus.FINISHED
            playerTurnRegex.containsMatchIn(normalized) ||
                dealerTurnRegex.containsMatchIn(normalized) -> ScreenStatus.IN_PROGRESS
            else -> ScreenStatus.UNKNOWN
        }
        val turn = when {
            playerTurnRegex.containsMatchIn(normalized) -> "PLAYER"
            dealerTurnRegex.containsMatchIn(normalized) -> "DEALER"
            else -> null
        }
        return ScreenSnapshot(
            roundId = round,
            playerScore = score?.groupValues?.get(1)?.toIntOrNull(),
            dealerScore = score?.groupValues?.get(2)?.toIntOrNull(),
            status = status,
            turn = turn,
            rawText = normalized
        )
    }
}
