package com.analytics.twentyone

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class LocalStats(
    val finished: Int,
    val draws: Int
)

class RoundStore(context: Context) : SQLiteOpenHelper(context, "21analytics.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE rounds (
                round_id INTEGER PRIMARY KEY,
                status TEXT NOT NULL,
                player_score INTEGER,
                dealer_score INTEGER,
                turn TEXT,
                is_draw INTEGER,
                finished_on_deal INTEGER,
                raw_text TEXT NOT NULL,
                updated_at INTEGER NOT NULL
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE rounds ADD COLUMN is_draw INTEGER")
            db.execSQL("ALTER TABLE rounds ADD COLUMN finished_on_deal INTEGER")
        }
    }

    fun save(snapshot: ScreenSnapshot) {
        val id = snapshot.roundId ?: return
        val finished = snapshot.status == ScreenStatus.FINISHED
        val draw: Int? = if (finished && snapshot.playerScore != null &&
            snapshot.dealerScore != null) {
            if (snapshot.playerScore == snapshot.dealerScore) 1 else 0
        } else null

        val values = ContentValues().apply {
            put("round_id", id)
            put("status", snapshot.status.name)
            put("player_score", snapshot.playerScore)
            put("dealer_score", snapshot.dealerScore)
            put("turn", snapshot.turn)
            if (draw == null) putNull("is_draw") else put("is_draw", draw)
            // R remains unknown until the app can reliably recognize card images.
            putNull("finished_on_deal")
            put("raw_text", snapshot.rawText)
            put("updated_at", System.currentTimeMillis())
        }
        writableDatabase.insertWithOnConflict(
            "rounds", null, values, SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun stats(): LocalStats {
        readableDatabase.rawQuery(
            "SELECT COUNT(*), COALESCE(SUM(CASE WHEN is_draw = 1 THEN 1 ELSE 0 END), 0) " +
                "FROM rounds WHERE status = 'FINISHED'", null
        ).use { cursor ->
            return if (cursor.moveToFirst()) {
                LocalStats(cursor.getInt(0), cursor.getInt(1))
            } else LocalStats(0, 0)
        }
    }
}
