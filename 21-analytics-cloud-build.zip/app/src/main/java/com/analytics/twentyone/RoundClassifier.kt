package com.analytics.twentyone

/**
 * Classification rules validated against the supplied 1xBet screenshots.
 * Card codes: rank + suit, e.g. AS = Ace of Spades, 10H = Ten of Hearts.
 */
data class RoundRecord(
    val roundId: Int,
    val playerScore: Int,
    val dealerScore: Int,
    val playerCards: List<String>,
    val dealerCards: List<String>,
    val winnerLabel: String
) {
    val isDraw: Boolean get() = playerScore == dealerScore

    // "Finished on deal" means neither side received an additional card:
    // exactly two initial cards for player and dealer.
    val finishedOnDeal: Boolean
        get() = playerCards.size == 2 && dealerCards.size == 2
}

data class RoundStats(
    val total: Int,
    val draws: Int,
    val finishedOnDeal: Int
) {
    val drawPercent: Double
        get() = if (total == 0) 0.0 else draws * 100.0 / total

    val finishedOnDealPercent: Double
        get() = if (total == 0) 0.0 else finishedOnDeal * 100.0 / total
}

object RoundClassifier {
    fun stats(rounds: List<RoundRecord>): RoundStats = RoundStats(
        total = rounds.size,
        draws = rounds.count { it.isDraw },
        finishedOnDeal = rounds.count { it.finishedOnDeal }
    )

    /**
     * Point values observed in the supplied examples:
     * 6-10 = face value; J=2; Q=3; K=4; A=11.
     * Validate against more official game examples before using this
     * to reconstruct scores from cards automatically.
     */
    fun cardPoints(cardCode: String): Int? {
        val rank = cardCode.dropLast(1).uppercase()
        return when (rank) {
            "J" -> 2
            "Q" -> 3
            "K" -> 4
            "A" -> 11
            else -> rank.toIntOrNull()?.takeIf { it in 6..10 }
        }
    }
}
