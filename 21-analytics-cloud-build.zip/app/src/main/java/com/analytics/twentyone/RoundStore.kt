package com.analytics.twentyone

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Local event log. One row per observed round; snapshots update the same round ID.
 * A round is counted in X/R statistics only after FINISHED is observed.
 */
class RoundStore(context: Context) : SQLiteOpenHelper(context, "21analytics.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE rounds (
                round_id INTEGER PRIMARY KEY,
                status TEXT NOT NULL,
                player_score INTEGER,
                dealer_score INTEGER,
                turn TEXT,
                raw_text TEXT NOT NULL,
                updated_at INTEGER NOT NULL
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Schema migrations will be added when card and event fields are finalized.
    }

    fun save(snapshot: ScreenSnapshot) {
        val id = snapshot.roundId ?: return
        val values = ContentValues().apply {
            put("round_id", id)
            put("status", snapshot.status.name)
            put("player_score", snapshot.playerScore)
            put("dealer_score", snapshot.dealerScore)
            put("turn", snapshot.turn)
            put("raw_text", snapshot.rawText)
            put("updated_at", System.currentTimeMillis())
        }
        writableDatabase.insertWithOnConflict("rounds", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun finishedRoundCount(): Int {
        readableDatabase.rawQuery(
            "SELECT COUNT(*) FROM rounds WHERE status = 'FINISHED'", null
        ).use { cursor ->
            return if (cursor.moveToFirst()) cursor.getInt(0) else 0
        }
    }
}
